package com.softtek;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.netflix.eureka.EnableEurekaClient;
import org.springframework.cloud.openfeign.EnableFeignClients;



//@RibbonClient(name = "servicio-productos")
@EnableFeignClients
@SpringBootApplication
@EnableEurekaClient
public class MicroServicioItemsApplication {

	public static void main(String[] args) {
		SpringApplication.run(MicroServicioItemsApplication.class, args);
	}

}
