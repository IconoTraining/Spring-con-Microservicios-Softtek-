insert into alumnos (nombre, nota) values ('Luis', 7.5);
insert into alumnos (nombre, nota) values ('Maria', 9.2);
insert into alumnos (nombre, nota) values ('Jose', 3.8);
insert into alumnos (nombre, nota) values ('Laura', 5.7);
insert into alumnos (nombre, nota) values ('Raquel', 10);