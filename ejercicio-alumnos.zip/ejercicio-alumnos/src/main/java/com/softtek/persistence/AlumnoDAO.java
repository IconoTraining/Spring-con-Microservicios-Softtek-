package com.softtek.persistence;

import org.springframework.data.repository.CrudRepository;

import com.softtek.entity.Alumno;

public interface AlumnoDAO extends CrudRepository<Alumno, Long>{

}
