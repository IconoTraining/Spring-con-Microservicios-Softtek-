package com.softtek.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.softtek.entity.Alumno;
import com.softtek.persistence.AlumnoDAO;

@Service
public class AlumnoServiceImpl implements IAlumnoService{
	
	@Autowired
	private AlumnoDAO alumnoDAO;

	@Override
	public List<Alumno> findAll() {
		return (List<Alumno>)alumnoDAO.findAll();
	}

	@Override
	public Alumno findById(Long numAlumno) {
		return alumnoDAO.findById(numAlumno).orElse(new Alumno());
	}

}
