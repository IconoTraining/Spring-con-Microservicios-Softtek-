package com.softtek.services;

import java.util.List;

import com.softtek.entity.Alumno;

public interface IAlumnoService {

	List<Alumno> findAll();
	Alumno findById(Long numAlumno);
}
