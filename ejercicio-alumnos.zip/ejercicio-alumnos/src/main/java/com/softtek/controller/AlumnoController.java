package com.softtek.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import com.softtek.entity.Alumno;
import com.softtek.services.IAlumnoService;

@RestController
public class AlumnoController {
	
	@Autowired
	private IAlumnoService alumnoService;
	
	// localhost:8001/todos
	@GetMapping("/todos")
	public List<Alumno> listar(){
		return alumnoService.findAll();
	}
	
	// localhost:8001/buscar/2
	@GetMapping("/buscar/{numAlumno}")
	public Alumno buscar(@PathVariable Long numAlumno) {
		return alumnoService.findById(numAlumno);
	}

}
