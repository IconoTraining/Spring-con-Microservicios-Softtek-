-- obligatoriamente este archivo se tiene que llamar import.sql
insert into productos (descripcion, precio) values ('Scanner', 129.50);
insert into productos (descripcion, precio) values ('Raton', 29.5);
insert into productos (descripcion, precio) values ('Pantalla', 129.50);
insert into productos (descripcion, precio) values ('Teclado', 50.35);