package com.softtek.persistence;

import java.util.List;

import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.data.rest.core.annotation.RepositoryRestResource;
import org.springframework.transaction.annotation.Isolation;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;


@RepositoryRestResource(collectionResourceRel = "productos", path = "productos")
public interface ProductoDAO extends CrudRepository<Producto, Long>{

	// http://localhost:8080/productos
	
	
	// Podemos utilizar los metodos heredados se CrudRepository
	// https://docs.spring.io/spring-data/jpa/docs/current/reference/html/
	
	// Podemos crear nuevos metodos utilizando las palabras clave
	// https://docs.spring.io/spring-data/jpa/docs/current/reference/html/#repository-query-keywords
	public List<Producto> findByDescripcion(@Param("descripcion") String descripcion);
	
	public List<Producto> findByPrecioOrderByDescripcionDesc(@Param("precio") double precio);
	
	
	@Override
	@Transactional(propagation = Propagation.REQUIRED, 
				isolation = Isolation.SERIALIZABLE, rollbackFor = Exception.class)
	<S extends Producto> S save(S entity);
		
}


