package com.softtek.filters;

import org.springframework.stereotype.Component;

import com.netflix.zuul.ZuulFilter;
import com.netflix.zuul.context.RequestContext;
import com.netflix.zuul.exception.ZuulException;

@Component
public class PostTiempoTranscurridoFilter extends ZuulFilter{

	@Override
	public boolean shouldFilter() {
		// si devuelve true se ejecuta el metodo run()
		// si devuelve false no se ejecuta
		return true;
	}

	@Override
	public Object run() throws ZuulException {
		// aqui se resuelve la logica de negocio
		// Aqui mediremos el tiempo de respuesta
		
		// Tomar el tiempo final
		Long tiempoFinal = System.currentTimeMillis();
		
		// Recuperar el tiempo de inicio
		RequestContext ctx = RequestContext.getCurrentContext();
		Long tiempoInicio = (Long) ctx.getRequest().getAttribute("tiempoInicio");
		
		
		// Mostrar en consola la diferencia de tiempos
		System.out.println("*************************************");
		System.out.println("Tiempo transcurrido " + (tiempoFinal - tiempoInicio) + " mseg.");
		System.out.println("*************************************");
		
		return null;
	}

	@Override
	public String filterType() {
		// Hay 3 tipos de filtro: pre, post y route
		// Ha de retornar uno de ellos
		return "post";
	}

	@Override
	public int filterOrder() {
		// Si hay varios filtros elegimos el orden de ejecucion
		return 0;
	}

}
