package com.softtek.controllers;

import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.env.Environment;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import com.softtek.models.entity.Producto;
import com.softtek.services.IProductoService;

@RestController
public class ProductoController {
	
	@Autowired
	private IProductoService productoService;
	
	@Value("${server.port}")
	private Integer port;
	
	@Autowired
	private Environment env;
	
	// localhost:8001/listar
	@GetMapping("/listar")
	public List<Producto> listar(){
		return productoService.findAll()
				.stream()
				.map(p -> {
					p.setPort(port);
					return p;
				}).collect(Collectors.toList());
	}
	
	// localhost:8001/ver/1
	@GetMapping("/ver/{id}")
	public Producto buscar(@PathVariable Long id) {
		Producto producto = productoService.findById(id);
		producto.setPort(port);
		return producto;
	}

}
