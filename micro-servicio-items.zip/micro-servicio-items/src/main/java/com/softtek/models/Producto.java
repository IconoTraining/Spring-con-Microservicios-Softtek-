package com.softtek.models;

import java.time.LocalDate;

public class Producto {

	private Long id;
	private String descripcion;
	private double precio;
	private LocalDate envasado;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getDescripcion() {
		return descripcion;
	}

	public void setDescripcion(String descripcion) {
		this.descripcion = descripcion;
	}

	public double getPrecio() {
		return precio;
	}

	public void setPrecio(double precio) {
		this.precio = precio;
	}

	public LocalDate getEnvasado() {
		return envasado;
	}

	public void setEnvasado(LocalDate envasado) {
		this.envasado = envasado;
	}

	@Override
	public String toString() {
		return "Producto [id=" + id + ", descripcion=" + descripcion + ", precio=" + precio + ", envasado=" + envasado
				+ "]";
	}

}
