package com.softtek;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import com.softtek.persistence.Producto;
import com.softtek.persistence.ProductoDAO;

@SpringBootApplication
public class Ejemplo3JpaRestApplication implements CommandLineRunner{
	
	@Autowired
	private ProductoDAO dao;

	public static void main(String[] args) {
		SpringApplication.run(Ejemplo3JpaRestApplication.class, args);	
	}

	@Override
	public void run(String... args) throws Exception {
		
		// Guardar productos
		dao.save(new Producto("Scanner", 129.50));
		dao.save(new Producto("Raton", 29.50));
		dao.save(new Producto("Pantalla", 129.50));
		dao.save(new Producto("Teclado", 50.35));
		
		// Mostrar todos los productos
		System.out.println("Todos los productos");
		System.out.println("-------------------");
		for(Producto p: dao.findAll()) {
			System.out.println(p);
		}
		
		// Buscar un producto por ID
		Optional<Producto> encontrado = dao.findById(2L);
		System.out.println(encontrado);
		
		// Buscar un producto por descripcion
		List<Producto> pantallas =  dao.findByDescripcion("Pantalla");
		System.out.println("Pantallas: " + pantallas);
		
		List<Producto> porPrecio = dao.findByPrecioOrderByDescripcionDesc(129.50);
		System.out.println(porPrecio);
		
	}
	
	
}


