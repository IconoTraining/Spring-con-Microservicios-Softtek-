package com.softtek.services;

import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Primary;
import org.springframework.stereotype.Service;

import com.softtek.clientes.ProductoClienteRest;
import com.softtek.models.Item;


@Service("serviceFeign")
// Una forma de solucionar cuando tenemos 2 beans del mismo tipo:
//@Primary   // da prioridad a este bean para DI
public class ItemServiceFeign implements ItemService{
	
	@Autowired
	private ProductoClienteRest clienteFeign;

	@Override
	public List<Item> findAll() {
		return clienteFeign.listar().stream()
				.map(p -> new Item(p, 1))
				.collect(Collectors.toList());
	}

	@Override
	public Item findById(Long id, Integer cantidad) {
		return new Item(clienteFeign.detalle(id), cantidad);
	}

}
