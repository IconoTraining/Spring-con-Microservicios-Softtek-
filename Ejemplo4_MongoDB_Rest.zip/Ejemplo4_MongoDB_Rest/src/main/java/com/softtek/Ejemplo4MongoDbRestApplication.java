package com.softtek;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import com.softtek.persistence.Producto;
import com.softtek.persistence.ProductoDAO;

@SpringBootApplication
public class Ejemplo4MongoDbRestApplication implements CommandLineRunner{
	
	@Autowired
	private ProductoDAO dao;

	public static void main(String[] args) {
		SpringApplication.run(Ejemplo4MongoDbRestApplication.class, args);
	}

	@Override
	public void run(String... args) throws Exception {
		
		// Borrar todos los datos
		//dao.deleteAll();
		
		// Alta de productos
		//dao.save(new Producto("Raton", 29.50));
		//dao.save(new Producto("Pantalla", 129.50));
		//dao.save(new Producto("Teclado", 55.90));
		//dao.save(new Producto("Scanner", 129.50));
		
		// Mostrar todos los productos
		System.out.println("Todos los productos");
		for(Producto p: dao.findAll()) {
			System.out.println(p);
		}
		
		// Buscar un producto por id
		System.out.println("Buscar por ID: " + dao.findById("6411f70a97ab705ebfb9b394"));
		
		// Buscar un producto por descripcion
		System.out.println("Buscar por descripcion: " + dao.findByDescripcion("Pantalla"));
		
		// Buscar por precio
		System.out.println("Buscar por precio: " + dao.findByPrecioOrderByDescripcionDesc(129.50));
		
	}

}
