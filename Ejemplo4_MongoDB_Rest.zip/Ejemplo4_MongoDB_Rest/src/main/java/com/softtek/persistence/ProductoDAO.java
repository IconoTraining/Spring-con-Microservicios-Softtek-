package com.softtek.persistence;

import java.util.List;

import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.data.rest.core.annotation.RepositoryRestResource;


@RepositoryRestResource(collectionResourceRel = "productos", path = "productos")
public interface ProductoDAO extends MongoRepository<Producto, String>{  // Ahora el ID es String

	// http://localhost:8080/productos
	
	
	// Podemos utilizar los metodos heredados de MongoRepository
	// https://docs.spring.io/spring-data/jpa/docs/current/reference/html/
	
	// Podemos crear nuevos metodos utilizando las palabras clave
	// https://docs.spring.io/spring-data/jpa/docs/current/reference/html/#repository-query-keywords
	public List<Producto> findByDescripcion(@Param("descripcion") String descripcion);
	
	public List<Producto> findByPrecioOrderByDescripcionDesc(@Param("precio") double precio);
	
	
}
