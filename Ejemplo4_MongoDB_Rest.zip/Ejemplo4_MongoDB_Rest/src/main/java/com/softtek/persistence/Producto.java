package com.softtek.persistence;

import java.io.Serializable;

import org.springframework.data.annotation.Id;


public class Producto implements Serializable {
	
	

	/**
	 * 
	 */
	private static final long serialVersionUID = -280370376526118126L;

	@Id 
	private String ID;  // Debe ser de tipo String 
	
	private String descripcion;
	private double precio;
	
	public Producto() {
		// TODO Auto-generated constructor stub
	}
	
	public Producto(String descripcion, double precio) {
		super();
		this.descripcion = descripcion;
		this.precio = precio;
	}

	public String getID() {
		return ID;
	}

	public void setID(String iD) {
		ID = iD;
	}

	public String getDescripcion() {
		return descripcion;
	}

	public void setDescripcion(String descripcion) {
		this.descripcion = descripcion;
	}

	public double getPrecio() {
		return precio;
	}

	public void setPrecio(double precio) {
		this.precio = precio;
	}

	@Override
	public String toString() {
		return "Producto [ID=" + ID + ", descripcion=" + descripcion + ", precio=" + precio + "]";
	}

}
