package com.softtek.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import com.netflix.hystrix.contrib.javanica.annotation.HystrixCommand;
import com.softtek.models.Item;
import com.softtek.models.Producto;
import com.softtek.services.ItemService;

@RestController
public class ItemController {
	
	@Autowired
	// Otra forma de solucionar las ambieguades cuando vamos a inyectar un bean
	// y hay mas de uno es poner el nombre del bean con @Qualifier
	//@Qualifier("serviceFeign")
	@Qualifier("serviceRestTemplate")
	private ItemService itemService;
	
	
	// localhost:8002/listar
	@GetMapping("/listar")
	public List<Item> listar(){
		return itemService.findAll();
	}
	
	
	// localhost:8002/ver/2/cantidad/5
	// En que caso de recibir una excepcion llamas al metodo manejarError
	@HystrixCommand(fallbackMethod = "manejarError")
	@GetMapping("/ver/{id}/cantidad/{cantidad}")
	public Item detalle(@PathVariable Long id, @PathVariable Integer cantidad) {
		return itemService.findById(id, cantidad);
	}
	
	
	public Item manejarError( Long id, Integer cantidad, Throwable ex) {
		
		System.err.println(ex.getMessage() + "------------------------");
	
		Producto producto = new Producto();
		producto.setId(id);
		producto.setDescripcion("Producto vacio");
		producto.setPrecio(0);
		
		Item item = new Item();
		item.setProducto(producto);
		item.setCantidad(0);
		
		return item;
	}

}
