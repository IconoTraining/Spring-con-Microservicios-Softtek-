package com.softtek.services;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;


// Anota la clase y la marca como un servicio REST
@RestController
public class SaludoRest {
	
	// http://localhost:8080/saludo
	@RequestMapping("/saludo")
	public String saludar() {
		return "Bienvenidos al curso de Microservicios";
	}
	
	// http://localhost:8080/adios?usuario=Pepe
	@RequestMapping("/adios")
	public String adios(@RequestParam(value = "usuario", defaultValue = "admin")  String user) {
		return "Adios " + user + " !!!";
	}

}
