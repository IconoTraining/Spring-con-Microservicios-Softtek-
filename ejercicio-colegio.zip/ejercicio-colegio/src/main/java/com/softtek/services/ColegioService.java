package com.softtek.services;

import java.util.List;

import com.softtek.models.Alumno;

public interface ColegioService {
	
	List<Alumno> todos();
	Alumno buscar(Long numAlumno);

}
