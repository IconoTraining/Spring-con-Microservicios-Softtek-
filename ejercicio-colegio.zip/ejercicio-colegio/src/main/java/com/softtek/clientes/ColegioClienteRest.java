package com.softtek.clientes;

import java.util.List;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import com.softtek.models.Alumno;

//@FeignClient(name = "servicio-alumnos", url="localhost:8001")
@FeignClient(name = "servicio-alumnos")
public interface ColegioClienteRest {

	@GetMapping("/todos")
	public List<Alumno> consultarTodos();
	
	@GetMapping("/buscar/{numAlumno}")
	public Alumno buscar(@PathVariable Long numAlumno);
}
