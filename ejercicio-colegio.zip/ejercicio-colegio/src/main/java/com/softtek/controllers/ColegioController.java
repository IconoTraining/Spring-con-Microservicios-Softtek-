package com.softtek.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import com.softtek.models.Alumno;
import com.softtek.services.ColegioService;

@RestController
public class ColegioController {
	
	@Autowired
	//@Qualifier("serviceFeign")
	@Qualifier("serviceRestTemplate")
	private ColegioService colegioService;
	
	// http://localhost:8002/listado
	@GetMapping("/listado")
	public List<Alumno> consultarTodos(){
		return colegioService.todos();
	}
	
	// http://localhost:8002/consultar/2
	@GetMapping("/consultar/{numAlumno}")
	public Alumno buscar(@PathVariable Long numAlumno) {
		return colegioService.buscar(numAlumno);
	}

}
